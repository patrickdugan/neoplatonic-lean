#!/usr/bin/env bash
# Run this from the root of a mathlib-enabled Lean project after copying
# Neoplatonic/ to that project root.
set -euo pipefail
for file in Core Amalgamation LocalConfluence Symmetry Models MergeModel CoherentModel Modal RH RHGeometry; do
  echo "Checking Neoplatonic/$file.lean"
  lake env lean "Neoplatonic/$file.lean"
done
echo "Every module was accepted by Lean."
